//
//  main.swift
//  a ➕b
//
//  Created by sq on 2018/9/19.
//  Copyright © 2018年 sq. All rights reserved.
//



import Foundation

print("Hello, World!")
var  a=78
var  b=78
var c=a+b
print(c)
